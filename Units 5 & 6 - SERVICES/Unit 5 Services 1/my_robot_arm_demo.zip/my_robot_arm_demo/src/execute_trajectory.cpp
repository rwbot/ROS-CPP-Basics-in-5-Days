#include "ros/ros.h"
// Import the service message used by the service /gazebo/delete_model
#include "gazebo_msgs/DeleteModel.h" 
// Import the service message used by the service /execute_trajectory
#include "iri_wam_reproduce_trajectory/ExecTraj.h"
#include <ros/package.h>

int main(int argc, char **argv){

    /* // Initialise a ROS node with the name service_client
    ros::init(argc, argv, "service_client"); 
    */
    // Initialise a ROS node with the name execute_trajectory_node
    ros::init(argc, argv, "execute_trajectory_node");
    ros::NodeHandle nh;


    // Search for service path using 'rosservice list | grep $SERVICE_NAME'
    // ROS DOCS
    // ros::ServiceClient client = nh.serviceClient<my_package::Foo>("my_service_name");

    /* // Create the connection to the service /gazebo/delete_model
    ros::ServiceClient delete_model_service = nh.serviceClient<gazebo_msgs::DeleteModel>("/gazebo/delete_model");
    // Create an object of type DeleteModel
    gazebo_msgs::DeleteModel srv; 
    // Fill the variable model_name of this object with the desired value
    srv.request.model_name = "bowl_1"; 
    */

    // Create the connection to the service /execute_trajectory
    ros::ServiceClient execute_trajectory_service = nh.serviceClient<iri_wam_reproduce_trajectory::ExecTraj>("/execute_trajectory");
    // Create an object of type ExecTraj
    iri_wam_reproduce_trajectory::ExecTraj trajectory;

    // Fill the variable file of this object with the desired value
    // This ros::package::getPath works in the same way as $(find name_of_package) in the launch files.
trajectory.request.file = ros::package::getPath("iri_wam_reproduce_trajectory") + "/config/get_food.txt";

    // Send through the connection the name of the object to be deleted by the service
    if (execute_trajectory_service.call(trajectory)){
        // Print the result given by the service called
        ROS_INFO("%s", "Service successfully called. Executing trajectory");
    }
    else{
        ROS_ERROR("Failed to call service execute_trajectory");
        return 1;
    }
    return 0;
}


#include <ros/ros.h>
// Here we are including all the headers necessary to use the most common public pieces of the ROS system.
// Always we create a new C++ file, we will need to add this include.

int main(int argc, char** argv) { // We start the main C++ program

    ros::init(argc, argv, "ObiWan"); // We initiate a ROS node called ObiWan
    ros::NodeHandle nh; // We create a handler for the node. This handler will actually do the initialization of the node
    /*
    ROS_INFO("Help me Obi-Wan Kenobi, you're my only hope"); // This is the same as a print in ROS
    
    ros::spinOnce();
    Calling ros::spinOnce() here is not necessary for this simple program, because we are not receiving any callbacks.
    However, if you were to add a subscription into this application, and did not have ros::spinOnce() here, 
    your callbacks would never get called. So, add it for good measure.
    */
    
    ros::Rate loop_rate(2); //Create a Rate Object of 2Hz
    
    while (ros::ok()) 
    {
        //endless loop until Ctrl + C
        ROS_INFO("Help me Obi-Wan Kenobi, you're my only hope"); 
        // This is the same as a print in ROS
        ros::spinOnce();
        loop_rate.sleep();  // We sleep the needed time to maintain the Rate fixed above
    } 
    return 0; // We end our program
}